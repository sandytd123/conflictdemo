package com.hoteldetailsservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hoteldetailservice.exception.RoomException;
import com.hoteldetailsservice.entity.AvailableRooms;
import com.hoteldetailsservice.serviceimpl.HotelServiceImpl;


@RestController
@CrossOrigin("*")
@RequestMapping("/hotel")
public class HotelDetailsController {
	@Autowired
    private  HotelServiceImpl hotelImpl;

	 
	
	@GetMapping("/getdetails/{price}/{roomType}")
	public List<AvailableRooms> Roomlist(@PathVariable(value="price") double price,@PathVariable(value="roomType") String roomType) throws RoomException{
		return hotelImpl.Roomlist(price, roomType);
		
	}

}
