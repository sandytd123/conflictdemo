package com.hoteldetailsservice.constant;

public class HotelDetailsContants {
	public static final String priceUrl="http://localhost:8085/getdetails/";
	public static final String inventoryUrl="http://localhost:8082/check/";
	public static final String addroomUrl="http://localhost:8085/addroom/";
	
	

}
