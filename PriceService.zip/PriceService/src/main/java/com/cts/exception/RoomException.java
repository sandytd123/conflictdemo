package com.cts.exception;

public class RoomException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public RoomException(String exception) {
		
		super(exception);
	}
	
	public RoomException() {
		super("no rooms r avilable for this price and roomtype");
	}
	
	


}
