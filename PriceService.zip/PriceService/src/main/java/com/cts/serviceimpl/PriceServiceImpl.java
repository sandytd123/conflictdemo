package com.cts.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.entity.PriceDetails;
import com.cts.exception.RoomException;
import com.cts.repository.PriceRepository;
import com.cts.service.PriceService;

@Service
public class PriceServiceImpl implements PriceService{
	@Autowired
	private PriceRepository repo;
	
	public List<PriceDetails> searchRoomDetails(Double price, String room_type) throws RoomException{
		List<PriceDetails> RoomDetails = null;
		RoomDetails =repo.findDetails(price, room_type);
		if(RoomDetails.size() > 0)
		{
			return RoomDetails;
		}else {
			throw new RoomException();
		}
	}

	@Override
	public PriceDetails addroom(PriceDetails room) {
		// TODO Auto-generated method stub
		return  repo.save(room);
	}

	@Override
	public void deleteroombyid(Integer id) {
		
	  repo.deleteById(id);
	}

	@Override
	public PriceDetails updateroom(PriceDetails room) {
		
		return repo.save(room);
	}

	
	

}
