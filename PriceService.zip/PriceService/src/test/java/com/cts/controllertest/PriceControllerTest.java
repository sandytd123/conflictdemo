package com.cts.controllertest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cts.PriceServiceApplication;
import com.cts.controller.PriceController;
import com.cts.entity.PriceDetails;
import com.cts.exception.RoomException;
import com.cts.repository.PriceRepository;
import com.cts.service.PriceService;
import com.cts.serviceimpl.PriceServiceImpl;
@SpringBootTest(classes = PriceServiceApplication.class)
class PriceControllerTest {
	
	@Mock
	PriceService service;
	
	
	@InjectMocks
	PriceController pricecontroller;
	
	@Test
	void testGetDetails() {
		List<PriceDetails> priceDetails= new ArrayList<>();
		priceDetails.add(new PriceDetails(1,500.0,"ac"));
		//System.out.println(service.searchRoomDetails(500.0, "ssssssssssssssssssssssssssss"));
		when(service.searchRoomDetails(500.0, "AC")).thenReturn(priceDetails);
		ResponseEntity<List<PriceDetails>> response = pricecontroller.getDetails(500.0, "AC");
		assertEquals(response.getStatusCode(),HttpStatus.OK);
	}
	@Test
	public void NoRoomFound() {
		List<PriceDetails> priceDetails= new ArrayList<PriceDetails>();
		Exception exception = assertThrows(RoomException.class, ()->{
		when(service.searchRoomDetails(4000.0, "AC")).thenReturn(priceDetails);
		pricecontroller.getDetails(4000.0, "AC");
	});
	}
}
