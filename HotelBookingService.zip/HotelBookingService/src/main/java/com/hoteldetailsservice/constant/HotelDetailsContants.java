package com.hoteldetailsservice.constant;

public class HotelDetailsContants {
	public static final String priceUrl="http://PriceService/price/getdetails/";
	public static final String inventoryUrl="http://InventoryService/inventory/check/";
	public static final String addroomUrl="http://localhost:8085/addroom/";
	
	

}
