package com.hoteldetailsservice.service;


import java.util.List;

import com.hoteldetailsservice.entity.AvailableRooms;


public interface HotelService {
	public List<AvailableRooms> Roomlist( double price, String roomType);
	public AvailableRooms addroom(AvailableRooms room);
}
