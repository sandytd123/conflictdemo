package com.hoteldetailsservice.serviceimpl;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.hoteldetailservice.exception.RoomException;
import com.hoteldetailsservice.constant.HotelDetailsContants;
import com.hoteldetailsservice.entity.AvailableRooms;
import com.hoteldetailsservice.entity.InventoryEntity;
import com.hoteldetailsservice.entity.PriceDetails;
import com.hoteldetailsservice.service.HotelService;

@Service
public class HotelServiceImpl implements HotelService {
	@Autowired
	RestTemplate restTemplate;
	
	public HotelServiceImpl() {
		
	}

	@Override

	public List<AvailableRooms> Roomlist( double price, String roomType){
		try{
			ResponseEntity<PriceDetails[]> showRoom=restTemplate.getForEntity(HotelDetailsContants.priceUrl+price+"/"+roomType, PriceDetails[].class);
			System.out.println(showRoom.getStatusCode());
			if(showRoom.getStatusCode().equals(HttpStatus.OK)){
				PriceDetails[] rooms=showRoom.getBody();
				List<AvailableRooms> Allrooms= Arrays.asList(rooms).stream().map(room ->{
					ResponseEntity<InventoryEntity> inventory = restTemplate.getForEntity(HotelDetailsContants.inventoryUrl + room.getId(), InventoryEntity.class);
					if(inventory.getStatusCode().equals(HttpStatus.OK)){
						return new AvailableRooms(room.getId(), inventory.getBody().getRoomType(),inventory.getBody().isAvailable(), room.getPrice());
					} /*
						 * else { throw new RoomException("hshjshjhsk"); }
						 */
					return null;
		        }).collect(Collectors.toList());
				return Allrooms;
			}
		}catch(RestClientException e) {
			e.getStackTrace();
			throw new RoomException();
		}
		return null;


//	@Override
//	public AvailableRooms addroom(AvailableRooms room) {
//		try {
//			PriceDetails detail=new PriceDetails();
//					AvailableRooms addedrooms=null;
//					detail.setPrice(room.getPrice());
//					detail.setRoomType(room.getRoomType());
//					ResponseEntity<PriceDetails> roomsave=restTemplate.getForEntity(HotelDetailsContants.addroomUrl, PriceDetails.class);
//					if(roomsave.getStatusCode().equals(HttpStatus.OK)) {
//						InventoryEntity inventory=new InventoryEntity();
//						inventory.setId(roomsave.getBody().getId());
//						inventory.setAvailable(room.getIsAvailable());
//					}
//						
//			
//		}
//		return null;
//	}

}

	@Override
	public AvailableRooms addroom(AvailableRooms room) {
		// TODO Auto-generated method stub
		return null;
	}
}