package com.hoteldetailsservice.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public  class AvailableRooms {
	
	private Integer id;
    private String roomType;
    private Boolean isAvailable;
    private Double price;
    

	
}
