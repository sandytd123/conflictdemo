package com.hoteldetailsservice.exception;

public class RoomException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public RoomException(String exception) {
		
		super(exception);
	}
	
	public RoomException() {
		super("no rooms are avaliable for this price and roomtype");
	}
	
	


}
