package com.cts.controllertest;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import com.cts.controller.InventoryController;
@RunWith(PowerMockRunner.class)
@PrepareForTest({InventoryController.class})
public class InventoryControllerTest {
	
	@InjectMocks
	InventoryController inventory;
	
	
	@Test
	public void  testpower() throws Exception{
		PowerMockito.mockStatic(InventoryController.class);
		when(InventoryController.testPower(10)).thenReturn(10);
		Integer test=InventoryController.testPower(10);
		Integer actual = new Integer(10);
		assertEquals(test, actual);
		
	}
	
	@Test
	public void testprivate() throws Exception{
		Integer data= (Integer) Whitebox.invokeMethod(inventory, "testprivate", 10);
		Integer actual=new Integer(10);
		assertEquals(data, actual);
	}

	

}
