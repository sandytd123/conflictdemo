package com.cts.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.entity.InventoryEntity;
import com.cts.repository.InventoryRepositary;
import com.cts.service.InventoryService;

@Service
public class InventoryServices implements InventoryService {
	 @Autowired
	private InventoryRepositary inventoryRepositary;
	 
	
	 public Optional<InventoryEntity> checkAvaliability(int id) {
		  return inventoryRepositary.findById(id);
	 }


	@Override
	public InventoryEntity getroom(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public InventoryEntity addroomInventory(InventoryEntity room) {
		// TODO Auto-generated method stub
		return inventoryRepositary.save(room);
	}


	@Override
	public InventoryEntity updateInventory(InventoryEntity updateroom) {
		// TODO Auto-generated method stub
		return inventoryRepositary.save(updateroom);
	}
	

}
